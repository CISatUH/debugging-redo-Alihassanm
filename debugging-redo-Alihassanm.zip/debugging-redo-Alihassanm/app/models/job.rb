class Job < ApplicationRecord
end
