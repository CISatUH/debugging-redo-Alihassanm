class Task < ApplicationRecord
  belongs_to :job
end
