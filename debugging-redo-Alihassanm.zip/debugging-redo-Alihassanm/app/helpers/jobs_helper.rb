module JobsHelper
end
